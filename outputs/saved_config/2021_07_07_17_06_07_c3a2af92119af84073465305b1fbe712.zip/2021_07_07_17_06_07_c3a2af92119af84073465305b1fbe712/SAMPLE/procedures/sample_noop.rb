require 'cosmos'
load_utility 'sample.rb'

sample = Sample.new
sample.noop
