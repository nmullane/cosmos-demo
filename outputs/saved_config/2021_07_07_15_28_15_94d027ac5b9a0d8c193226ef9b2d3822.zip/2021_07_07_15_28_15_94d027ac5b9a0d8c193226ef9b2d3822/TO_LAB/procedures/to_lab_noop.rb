require 'cosmos'
load_utility 'to_lab.rb'

to_lab = ToLab.new
to_lab.noop
